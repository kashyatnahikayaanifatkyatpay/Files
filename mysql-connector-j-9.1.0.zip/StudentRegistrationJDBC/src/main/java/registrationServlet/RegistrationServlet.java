package registrationServlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public RegistrationServlet() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Database credentials and URL
        String jdbcUrl = "jdbc:mysql://localhost:3306/Registration"; // Update database name
        String dbUsername = "root"; // Update database username
        String dbPassword = "0000"; // Update database password

        // Retrieve form data
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String course = request.getParameter("course");
        String rollNo = request.getParameter("rollNo");

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUsername, dbPassword)) {
            // SQL query to insert student data
            String sql = "INSERT INTO Students (name, email, course, roll_no) VALUES (?, ?, ?, ?)";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, name);
                ps.setString(2, email);
                ps.setString(3, course);
                ps.setString(4, rollNo);

                int rowsInserted = ps.executeUpdate();
                if (rowsInserted > 0) {
                    // Success - forward to Welcome page
                    RequestDispatcher rd = request.getRequestDispatcher("Welcome.jsp");
                    rd.forward(request, response);
                } else {
                    // Failure - redirect back with an error
                    response.sendRedirect("Registration.jsp?error=1");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("Registration.jsp?error=1");
        }
    }
}
