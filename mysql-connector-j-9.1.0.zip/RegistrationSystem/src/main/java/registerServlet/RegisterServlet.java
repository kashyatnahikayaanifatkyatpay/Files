package registerServlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
        String name = req.getParameter("name");
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        String gender = req.getParameter("gender");

        String jdbcUrl = "jdbc:mysql://localhost:3306/Registration"; // Replace with your database details
        String dbUser = "root";
        String dbPassword = "0000";

        res.setContentType("text/html");
        PrintWriter out = res.getWriter();

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            Class.forName("com.mysql.cj.jdbc.Driver");

            String query = "INSERT INTO Users (name, email, password, gender) VALUES (?, ?, ?, ?)";
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                ps.setString(1, name);
                ps.setString(2, email);
                ps.setString(3, password); // Ideally, hash the password before storing
                ps.setString(4, gender);

                int result = ps.executeUpdate();
                if (result > 0) {
                    out.println("<h3>Registration Successful!</h3>");
                    out.println("<p>Welcome, " + name + " (" + gender + ")</p>");
                } else {
                    out.println("<h3>Registration Failed. Please try again.</h3>");
                }
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            out.println("<h3>Error: Unable to register. Please try again later.</h3>");
        }
    }
}
