package cartServlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

@WebServlet("/RemoveItemServlet")
public class RemoveItemServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String product = request.getParameter("product");
        HttpSession session = request.getSession();

        @SuppressWarnings("unchecked")
        List<String> cart = (List<String>) session.getAttribute("cart");

        if (cart != null && product != null) {
            cart.remove(product);
        }

        session.setAttribute("cart", cart);
        response.sendRedirect("Viewcart.jsp");
    }
}
