package library;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/BookSearchServlet")
public class BookSearchServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        String genre = request.getParameter("genre");
        String year = request.getParameter("year");

        List<String[]> books = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibraryDB", "root", "0000");

            StringBuilder sql = new StringBuilder("SELECT * FROM books WHERE 1=1");
            if (title != null && !title.isEmpty()) {
                sql.append(" AND title LIKE ?");
            }
            if (author != null && !author.isEmpty()) {
                sql.append(" AND author LIKE ?");
            }
            if (genre != null && !genre.isEmpty()) {
                sql.append(" AND genre LIKE ?");
            }
            if (year != null && !year.isEmpty()) {
                sql.append(" AND year = ?");
            }

            PreparedStatement statement = connection.prepareStatement(sql.toString());

            int index = 1;
            if (title != null && !title.isEmpty()) {
                statement.setString(index++, "%" + title + "%");
            }
            if (author != null && !author.isEmpty()) {
                statement.setString(index++, "%" + author + "%");
            }
            if (genre != null && !genre.isEmpty()) {
                statement.setString(index++, "%" + genre + "%");
            }
            if (year != null && !year.isEmpty()) {
                statement.setInt(index++, Integer.parseInt(year));
            }

            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                books.add(new String[]{
                    rs.getString("title"),
                    rs.getString("author"),
                    rs.getString("genre"),
                    String.valueOf(rs.getInt("year"))
                });
            }

            rs.close();
            statement.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("books", books);
        RequestDispatcher dispatcher = request.getRequestDispatcher("results.jsp");
        dispatcher.forward(request, response);
    }
}
